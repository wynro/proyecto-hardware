/**
 * @file still-alive-lyrics.h
 * @brief Archivo de recursos con los creditos finales
 * @author Guillermo Robles
 */
#ifndef STILL_ALIVE_LYRICS_H_
#define STILL_ALIVE_LYRICS_H_

#define STILL_ALIVE_SIZE 117

// Todos los derechos rservados a sus respectivos due�os 

char *still_alive[STILL_ALIVE_SIZE];
#endif /* STILL_ALIVE_LYRICS_H_ */
