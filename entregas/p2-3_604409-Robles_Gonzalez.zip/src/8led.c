/*********************************************************************************************
 * Fichero:	8led.c
 * Autor:
 * Descrip:	Funciones de control del display 8-segmentos
 * Version:
 *********************************************************************************************/


#include "44b.h"
#include "44blib.h"



/**
 * Mapa de bits de cada segmento (valor que se debe escribir en el
 * display para que se ilumine el segmento)
 */
enum {
	cero = ~0xED,
	uno = ~0x60,
	dos = ~0xCE,
	tres = ~0xEA,
	cuatro = ~0x63,
	cinco = ~0xAB,
	seis = ~0x2F,
	siete = ~0xE0,
	ocho = ~0xEF,
	nueve = ~0xE3,
	A = ~0xE7,
	B = ~0x2F,
	C = ~0x8D,
	D = ~0x6E,
	E = ~0x8F,
	F = ~0x87,
	blank = ~0x00,
	size_8led = 17
};


int Symbol[size_8led] = { cero, uno, dos, tres, cuatro, cinco, seis, siete,
		ocho, nueve, A, B, C, D, E, F, blank };
int valor_actual;

/*--- c�digo de las funciones ---*/
void D8Led_init(void) {
	LED8ADDR = (unsigned char)cero;
	valor_actual = 0;
}

void D8Led_symbol(int value) {
	if ((value >= 0) && (value < size_8led)) {
		LED8ADDR = Symbol[value];
		valor_actual = value;
	}
}

int D8Led_current_symbol(void) {
	return valor_actual;
}


void D8Led_blink_symbol(int value, int ms) {
	int aux = valor_actual;
	D8Led_symbol(value);
	DelayMs(ms);
	D8Led_symbol(aux);
}

